<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Account</label>
    <protected>false</protected>
    <values>
        <field>Opportunity_Field__c</field>
        <value xsi:type="xsd:string">AccountId</value>
    </values>
    <values>
        <field>Pricing_Tool__c</field>
        <value xsi:type="xsd:string">AMESA;TS Japan;OCE</value>
    </values>
    <values>
        <field>Quote_Field__c</field>
        <value xsi:type="xsd:string">Apttus_Proposal__Account__c</value>
    </values>
</CustomMetadata>
